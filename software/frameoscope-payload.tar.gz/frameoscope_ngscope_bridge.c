#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <inttypes.h>
#include <libusb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define FTDI_VID 0x0403
#define FTDI_PID 0x6014
#define FTDI_IFACE 0
#define FTDI_INDEX_A 1
#define FTDI_EP_IN 0x81
#define FTDI_PACKET_SIZE 512

#define SIO_RESET_REQUEST 0
#define SIO_SET_LATENCY_TIMER_REQUEST 9
#define SIO_SET_BITMODE_REQUEST 11
#define SIO_RESET_SIO 0
#define SIO_RESET_PURGE_RX 1
#define SIO_RESET_PURGE_TX 2
#define BITMODE_RESET 0x00
#define BITMODE_SYNCFF 0x40

#define DEFAULT_SAMPLE_RATE_HZ 30000000ULL
#define DEFAULT_CONTROL_PORT 5025
#define DEFAULT_DATA_PORT 5026
#define DEFAULT_RING_MIB 192
#define DEFAULT_DEPTH 10000ULL
#define DEFAULT_DISCARD 16384ULL
#define DEFAULT_TRANSFERS 16
#define DEFAULT_TRANSFER_SIZE (256 * 1024)
#define ADC_BNC_FULL_SCALE_VOLTS 5.20f
#define DSLABS_DEFAULT_ATTENUATION 10.0f

struct sample_ring {
    uint8_t *data;
    size_t size;
    uint64_t total;
    pthread_mutex_t lock;
    pthread_cond_t cond;
};

struct bridge_ctx;

struct transfer_slot {
    struct libusb_transfer *transfer;
    unsigned char *raw;
    unsigned char *payload;
    struct bridge_ctx *ctx;
};

struct bridge_ctx {
    struct sample_ring ring;
    libusb_context *usb;
    libusb_device_handle *handle;
    struct transfer_slot *slots;
    pthread_t thread;
    pthread_mutex_t ready_lock;
    pthread_cond_t ready_cond;
    int num_transfers;
    int transfer_size;
    int active;
    int stopping;
    int synthetic;
    int verbose;
    int ready;
    int ok;
    uint64_t discard_remaining;
    uint64_t raw_bytes;
    uint64_t payload_bytes;
    uint64_t ring_bytes;
    double start_s;
    double next_report_s;
    char error[256];
};

struct server_state {
    struct bridge_ctx *bridge;
    pthread_mutex_t lock;
    uint64_t sample_depth;
    uint64_t sample_rate;
    uint32_t seqnum;
    int armed;
    double last_frame_s;
};

struct session_ctx {
    struct server_state *state;
    int control_sock;
    int data_sock;
};

static volatile sig_atomic_t interrupted;

static void on_signal(int signum)
{
    (void)signum;
    interrupted = 1;
}

static void install_signal_handlers(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
}

static double now_s(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1000000000.0;
}

static int parse_int(const char *text, int min_value, int max_value, const char *name)
{
    char *end = NULL;
    errno = 0;
    long value = strtol(text, &end, 0);
    if (errno || !end || *end || value < min_value || value > max_value) {
        fprintf(stderr, "invalid %s: %s\n", name, text);
        exit(2);
    }
    return (int)value;
}

static uint64_t parse_u64(const char *text, const char *name)
{
    char *end = NULL;
    errno = 0;
    unsigned long long value = strtoull(text, &end, 0);
    if (errno || !end || *end) {
        fprintf(stderr, "invalid %s: %s\n", name, text);
        exit(2);
    }
    return (uint64_t)value;
}

static int64_t sample_rate_to_fs(uint64_t sample_rate_hz)
{
    const uint64_t fs_per_s = 1000000000000000ULL;
    return (int64_t)((fs_per_s + (sample_rate_hz / 2)) / sample_rate_hz);
}

static int ring_init(struct sample_ring *ring, size_t size)
{
    memset(ring, 0, sizeof(*ring));
    ring->data = malloc(size);
    if (!ring->data) {
        return -1;
    }
    ring->size = size;
    pthread_mutex_init(&ring->lock, NULL);
    pthread_cond_init(&ring->cond, NULL);
    return 0;
}

static void ring_destroy(struct sample_ring *ring)
{
    free(ring->data);
    pthread_mutex_destroy(&ring->lock);
    pthread_cond_destroy(&ring->cond);
}

static void ring_write(struct sample_ring *ring, const uint8_t *data, size_t len)
{
    if (len == 0) {
        return;
    }

    pthread_mutex_lock(&ring->lock);

    if (len >= ring->size) {
        data += len - ring->size;
        len = ring->size;
    }

    size_t pos = (size_t)(ring->total % ring->size);
    size_t first = ring->size - pos;
    if (first > len) {
        first = len;
    }
    memcpy(ring->data + pos, data, first);
    if (len > first) {
        memcpy(ring->data, data + first, len - first);
    }

    ring->total += len;
    pthread_cond_broadcast(&ring->cond);
    pthread_mutex_unlock(&ring->lock);
}

static int ring_read_latest(struct sample_ring *ring, uint8_t *dst, size_t len, int *short_read)
{
    *short_read = 0;
    pthread_mutex_lock(&ring->lock);
    while (!interrupted && ring->total < len) {
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 10;
        int rc = pthread_cond_timedwait(&ring->cond, &ring->lock, &ts);
        if (rc == ETIMEDOUT) {
            break;
        }
    }

    uint64_t available = ring->total;
    if (available == 0) {
        pthread_mutex_unlock(&ring->lock);
        return -1;
    }

    if (available < len) {
        size_t missing = len - (size_t)available;
        memset(dst, 0, missing);
        dst += missing;
        len = (size_t)available;
        *short_read = 1;
    }

    uint64_t start = ring->total - len;
    size_t pos = (size_t)(start % ring->size);
    size_t first = ring->size - pos;
    if (first > len) {
        first = len;
    }
    memcpy(dst, ring->data + pos, first);
    if (len > first) {
        memcpy(dst + first, ring->data, len - first);
    }

    pthread_mutex_unlock(&ring->lock);
    return 0;
}

static int ftdi_ctrl(libusb_device_handle *handle, uint8_t request,
                     uint16_t value, uint16_t index)
{
    int rc = libusb_control_transfer(
        handle,
        LIBUSB_ENDPOINT_OUT | LIBUSB_REQUEST_TYPE_VENDOR | LIBUSB_RECIPIENT_DEVICE,
        request,
        value,
        index,
        NULL,
        0,
        1000);
    return rc < 0 ? rc : 0;
}

static int configure_sync_fifo(libusb_device_handle *handle)
{
    int rc;

    rc = ftdi_ctrl(handle, SIO_SET_LATENCY_TIMER_REQUEST, 2, FTDI_INDEX_A);
    if (rc < 0) return rc;
    rc = ftdi_ctrl(handle, SIO_RESET_REQUEST, SIO_RESET_SIO, FTDI_INDEX_A);
    if (rc < 0) return rc;
    rc = ftdi_ctrl(handle, SIO_SET_BITMODE_REQUEST,
                   (BITMODE_RESET << 8) | 0x00, FTDI_INDEX_A);
    if (rc < 0) return rc;
    usleep(20000);
    rc = ftdi_ctrl(handle, SIO_SET_BITMODE_REQUEST,
                   (BITMODE_SYNCFF << 8) | 0xff, FTDI_INDEX_A);
    if (rc < 0) return rc;
    usleep(50000);
    rc = ftdi_ctrl(handle, SIO_RESET_REQUEST, SIO_RESET_PURGE_RX, FTDI_INDEX_A);
    if (rc < 0) return rc;
    rc = ftdi_ctrl(handle, SIO_RESET_REQUEST, SIO_RESET_PURGE_TX, FTDI_INDEX_A);
    if (rc < 0) return rc;
    return 0;
}

static void bridge_set_ready(struct bridge_ctx *ctx, int ok, const char *message)
{
    pthread_mutex_lock(&ctx->ready_lock);
    ctx->ready = 1;
    ctx->ok = ok;
    if (message) {
        snprintf(ctx->error, sizeof(ctx->error), "%s", message);
    }
    pthread_cond_broadcast(&ctx->ready_cond);
    pthread_mutex_unlock(&ctx->ready_lock);
}

static void process_raw_to_ring(struct bridge_ctx *ctx, struct transfer_slot *slot, int len)
{
    int out = 0;
    ctx->raw_bytes += (uint64_t)len;

    for (int offset = 0; offset < len; offset += FTDI_PACKET_SIZE) {
        int packet_len = len - offset;
        if (packet_len > FTDI_PACKET_SIZE) {
            packet_len = FTDI_PACKET_SIZE;
        }
        if (packet_len <= 2) {
            continue;
        }

        const unsigned char *payload = slot->raw + offset + 2;
        int payload_len = packet_len - 2;
        ctx->payload_bytes += (uint64_t)payload_len;

        int skip = 0;
        if (ctx->discard_remaining) {
            skip = ctx->discard_remaining >= (uint64_t)payload_len ?
                payload_len : (int)ctx->discard_remaining;
            ctx->discard_remaining -= (uint64_t)skip;
        }

        int write_len = payload_len - skip;
        if (write_len > 0) {
            memcpy(slot->payload + out, payload + skip, (size_t)write_len);
            out += write_len;
        }
    }

    if (out > 0) {
        ring_write(&ctx->ring, slot->payload, (size_t)out);
        ctx->ring_bytes += (uint64_t)out;
    }
}

static void print_usb_report(struct bridge_ctx *ctx)
{
    double elapsed = now_s() - ctx->start_s;
    if (elapsed <= 0.0) {
        elapsed = 1e-9;
    }
    double payload_mbps = (double)ctx->ring_bytes / elapsed / 1000000.0;
    double raw_mbps = (double)ctx->raw_bytes / elapsed / 1000000.0;
    fprintf(stderr,
            "usb %.1fs  ring=%" PRIu64 " bytes  payload=%.3f MB/s  raw=%.3f MB/s\n",
            elapsed, ctx->ring_bytes, payload_mbps, raw_mbps);
}

static void LIBUSB_CALL transfer_cb(struct libusb_transfer *transfer)
{
    struct transfer_slot *slot = (struct transfer_slot *)transfer->user_data;
    struct bridge_ctx *ctx = slot->ctx;

    if (transfer->status == LIBUSB_TRANSFER_COMPLETED && transfer->actual_length > 0) {
        process_raw_to_ring(ctx, slot, transfer->actual_length);
    } else if (transfer->status != LIBUSB_TRANSFER_CANCELLED && !ctx->stopping) {
        fprintf(stderr, "bulk transfer ended with status %d\n", transfer->status);
        ctx->stopping = 1;
    }

    double t = now_s();
    if (ctx->verbose && t >= ctx->next_report_s) {
        print_usb_report(ctx);
        ctx->next_report_s = t + 1.0;
    }

    if (!ctx->stopping && !interrupted) {
        int rc = libusb_submit_transfer(transfer);
        if (rc == 0) {
            return;
        }
        fprintf(stderr, "libusb_submit_transfer failed: %s\n", libusb_error_name(rc));
        ctx->stopping = 1;
    }

    ctx->active--;
}

static void free_usb_resources(struct bridge_ctx *ctx)
{
    if (ctx->slots) {
        for (int i = 0; i < ctx->num_transfers; i++) {
            if (ctx->slots[i].transfer) {
                libusb_free_transfer(ctx->slots[i].transfer);
            }
            free(ctx->slots[i].raw);
            free(ctx->slots[i].payload);
        }
        free(ctx->slots);
        ctx->slots = NULL;
    }
    if (ctx->handle) {
        libusb_release_interface(ctx->handle, FTDI_IFACE);
        libusb_close(ctx->handle);
        ctx->handle = NULL;
    }
    if (ctx->usb) {
        libusb_exit(ctx->usb);
        ctx->usb = NULL;
    }
}

static void *usb_thread_main(void *arg)
{
    struct bridge_ctx *ctx = (struct bridge_ctx *)arg;
    int rc = libusb_init(&ctx->usb);
    if (rc < 0) {
        bridge_set_ready(ctx, 0, libusb_error_name(rc));
        return NULL;
    }

    ctx->handle = libusb_open_device_with_vid_pid(ctx->usb, FTDI_VID, FTDI_PID);
    if (!ctx->handle) {
        bridge_set_ready(ctx, 0, "FT232H not found or not accessible");
        free_usb_resources(ctx);
        return NULL;
    }

    if (libusb_kernel_driver_active(ctx->handle, FTDI_IFACE) == 1) {
        rc = libusb_detach_kernel_driver(ctx->handle, FTDI_IFACE);
        if (rc < 0) {
            bridge_set_ready(ctx, 0, libusb_error_name(rc));
            free_usb_resources(ctx);
            return NULL;
        }
    }

    rc = libusb_claim_interface(ctx->handle, FTDI_IFACE);
    if (rc < 0) {
        bridge_set_ready(ctx, 0, libusb_error_name(rc));
        free_usb_resources(ctx);
        return NULL;
    }

    rc = configure_sync_fifo(ctx->handle);
    if (rc < 0) {
        bridge_set_ready(ctx, 0, libusb_error_name(rc));
        free_usb_resources(ctx);
        return NULL;
    }

    ctx->slots = calloc((size_t)ctx->num_transfers, sizeof(*ctx->slots));
    if (!ctx->slots) {
        bridge_set_ready(ctx, 0, "calloc failed");
        free_usb_resources(ctx);
        return NULL;
    }

    ctx->start_s = now_s();
    ctx->next_report_s = ctx->start_s + 1.0;

    for (int i = 0; i < ctx->num_transfers; i++) {
        ctx->slots[i].ctx = ctx;
        ctx->slots[i].raw = malloc((size_t)ctx->transfer_size);
        ctx->slots[i].payload = malloc((size_t)ctx->transfer_size);
        ctx->slots[i].transfer = libusb_alloc_transfer(0);
        if (!ctx->slots[i].raw || !ctx->slots[i].payload || !ctx->slots[i].transfer) {
            bridge_set_ready(ctx, 0, "transfer allocation failed");
            ctx->stopping = 1;
            break;
        }

        libusb_fill_bulk_transfer(ctx->slots[i].transfer, ctx->handle, FTDI_EP_IN,
                                  ctx->slots[i].raw, ctx->transfer_size,
                                  transfer_cb, &ctx->slots[i], 1000);
        rc = libusb_submit_transfer(ctx->slots[i].transfer);
        if (rc < 0) {
            bridge_set_ready(ctx, 0, libusb_error_name(rc));
            ctx->stopping = 1;
            break;
        }
        ctx->active++;
    }

    if (!ctx->ready) {
        bridge_set_ready(ctx, 1, "ok");
    }

    while (ctx->active > 0) {
        if (interrupted && !ctx->stopping) {
            ctx->stopping = 1;
            for (int i = 0; i < ctx->num_transfers; i++) {
                if (ctx->slots[i].transfer) {
                    libusb_cancel_transfer(ctx->slots[i].transfer);
                }
            }
        }
        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 100000;
        libusb_handle_events_timeout(ctx->usb, &tv);
    }

    if (ctx->verbose) {
        print_usb_report(ctx);
    }
    free_usb_resources(ctx);
    return NULL;
}

static void *synthetic_thread_main(void *arg)
{
    struct bridge_ctx *ctx = (struct bridge_ctx *)arg;
    uint8_t *buf = malloc(64 * 1024);
    if (!buf) {
        bridge_set_ready(ctx, 0, "synthetic buffer allocation failed");
        return NULL;
    }

    ctx->start_s = now_s();
    ctx->next_report_s = ctx->start_s + 1.0;
    bridge_set_ready(ctx, 1, "ok");

    uint8_t v = 0;
    while (!ctx->stopping && !interrupted) {
        for (size_t i = 0; i < 64 * 1024; i++) {
            buf[i] = v++;
        }
        ring_write(&ctx->ring, buf, 64 * 1024);
        ctx->ring_bytes += 64 * 1024;
        ctx->payload_bytes += 64 * 1024;
        ctx->raw_bytes += 64 * 1024;

        double t = now_s();
        if (ctx->verbose && t >= ctx->next_report_s) {
            print_usb_report(ctx);
            ctx->next_report_s = t + 1.0;
        }
        usleep(2000);
    }

    free(buf);
    return NULL;
}

static int send_all(int fd, const void *buf, size_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    while (len) {
        ssize_t rc = send(fd, p, len, MSG_NOSIGNAL);
        if (rc < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
        if (rc == 0) {
            return -1;
        }
        p += rc;
        len -= (size_t)rc;
    }
    return 0;
}

static int recv_line(int fd, char *buf, size_t len)
{
    size_t pos = 0;
    while (pos + 1 < len) {
        char c;
        ssize_t rc = recv(fd, &c, 1, 0);
        if (rc < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
        if (rc == 0) {
            return 0;
        }
        if (c == '\n') {
            break;
        }
        if (c != '\r') {
            buf[pos++] = c;
        }
    }
    buf[pos] = 0;
    return 1;
}

static int create_listener(int port)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket");
        return -1;
    }

    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons((uint16_t)port);

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(fd);
        return -1;
    }
    if (listen(fd, 4) < 0) {
        perror("listen");
        close(fd);
        return -1;
    }
    return fd;
}

static void set_socket_options(int fd)
{
    int one = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
}

static int accept_client(int listener, const char *name)
{
    while (!interrupted) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(listener, &rfds);
        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 100000;

        int ready = select(listener + 1, &rfds, NULL, NULL, &tv);
        if (ready < 0) {
            if (errno == EINTR) {
                continue;
            }
            perror("select");
            return -1;
        }
        if (ready == 0) {
            continue;
        }

        int fd = accept(listener, NULL, NULL);
        if (fd >= 0) {
            set_socket_options(fd);
            fprintf(stderr, "%s client connected\n", name);
            return fd;
        }
        if (errno == EINTR) {
            if (interrupted) {
                return -1;
            }
            continue;
        }
        perror("accept");
        return -1;
    }
    return -1;
}

static int send_reply(int fd, const char *reply)
{
    return send_all(fd, reply, strlen(reply));
}

static void build_depths_reply(struct server_state *state, char *buf, size_t len)
{
    size_t ring_size = state->bridge->ring.size;
    uint64_t candidates[] = {
        10000ULL,
        30000ULL,
        300000ULL,
        3000000ULL,
        30000000ULL,
        150000000ULL,
    };

    buf[0] = 0;
    size_t used = 0;
    for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); i++) {
        if (candidates[i] > ring_size) {
            continue;
        }
        int rc = snprintf(buf + used, len - used, "%" PRIu64 ",", candidates[i]);
        if (rc < 0 || (size_t)rc >= len - used) {
            break;
        }
        used += (size_t)rc;
    }
    if (used + 2 < len) {
        buf[used++] = '\n';
        buf[used] = 0;
    }
}

static uint64_t get_sample_depth(struct server_state *state)
{
    pthread_mutex_lock(&state->lock);
    uint64_t depth = state->sample_depth;
    pthread_mutex_unlock(&state->lock);

    if (depth < 1) {
        depth = 1;
    }
    if (depth > state->bridge->ring.size) {
        depth = state->bridge->ring.size;
    }
    return depth;
}

static uint32_t next_seqnum(struct server_state *state, double *wfms_s)
{
    double t = now_s();
    pthread_mutex_lock(&state->lock);
    uint32_t seq = ++state->seqnum;
    if (state->last_frame_s > 0) {
        double dt = t - state->last_frame_s;
        *wfms_s = dt > 0.0 ? 1.0 / dt : 0.0;
    } else {
        *wfms_s = 0.0;
    }
    state->last_frame_s = t;
    pthread_mutex_unlock(&state->lock);
    return seq;
}

static int send_frame(struct session_ctx *session)
{
    struct server_state *state = session->state;
    uint64_t depth64 = get_sample_depth(state);
    if (depth64 > SIZE_MAX) {
        depth64 = SIZE_MAX;
    }
    size_t depth = (size_t)depth64;

    uint8_t *samples = malloc(depth);
    if (!samples) {
        fprintf(stderr, "failed to allocate %" PRIu64 " samples\n", depth64);
        return -1;
    }

    int short_read = 0;
    if (ring_read_latest(&state->bridge->ring, samples, depth, &short_read) < 0) {
        free(samples);
        return -1;
    }
    if (short_read) {
        fprintf(stderr, "warning: frame padded because the ring has not filled yet\n");
    }

    double wfms_s = 0.0;
    uint32_t seqnum = next_seqnum(state, &wfms_s);
    uint16_t num_channels = 1;
    pthread_mutex_lock(&state->lock);
    uint64_t sample_rate = state->sample_rate;
    pthread_mutex_unlock(&state->lock);
    int64_t fs_per_sample = sample_rate_to_fs(sample_rate);
    int64_t trigger_fs = (int64_t)(depth64 / 2) * fs_per_sample;
    size_t chnum = 0;
    size_t memdepth = depth;
    float config[3];
    config[0] = ADC_BNC_FULL_SCALE_VOLTS / (255.0f * DSLABS_DEFAULT_ATTENUATION);
    config[1] = 0.0f;
    config[2] = 0.0f;
    uint8_t clipping = 0;

    int ok = 0;
    ok |= send_all(session->data_sock, &seqnum, sizeof(seqnum));
    ok |= send_all(session->data_sock, &num_channels, sizeof(num_channels));
    ok |= send_all(session->data_sock, &fs_per_sample, sizeof(fs_per_sample));
    ok |= send_all(session->data_sock, &trigger_fs, sizeof(trigger_fs));
    ok |= send_all(session->data_sock, &wfms_s, sizeof(wfms_s));
    ok |= send_all(session->data_sock, &chnum, sizeof(chnum));
    ok |= send_all(session->data_sock, &memdepth, sizeof(memdepth));
    ok |= send_all(session->data_sock, config, sizeof(config));
    ok |= send_all(session->data_sock, &clipping, sizeof(clipping));
    ok |= send_all(session->data_sock, samples, depth);

    free(samples);
    if (ok < 0) {
        return -1;
    }
    if (state->bridge->verbose) {
        fprintf(stderr, "sent frame seq=%u depth=%zu fs_per_sample=%" PRId64 "\n",
                seqnum, depth, fs_per_sample);
    }
    return 0;
}

static void handle_command(struct session_ctx *session, const char *line)
{
    struct server_state *state = session->state;

    if (state->bridge->verbose && line[0] &&
        strcmp(line, "RATES?") && strcmp(line, "DEPTHS?")) {
        fprintf(stderr, "scpi %s\n", line);
    }

    if (!strcmp(line, "*IDN?")) {
        send_reply(session->control_sock,
                   "DreamSourceLab,DSCope U3P100,FRAMEOSCOPE,0.1\n");
    } else if (!strcmp(line, "RATES?")) {
        char reply[64];
        pthread_mutex_lock(&state->lock);
        int64_t fs_per_sample = sample_rate_to_fs(state->sample_rate);
        pthread_mutex_unlock(&state->lock);
        snprintf(reply, sizeof(reply), "%" PRId64 ",\n", fs_per_sample);
        send_reply(session->control_sock, reply);
    } else if (!strcmp(line, "DEPTHS?")) {
        char reply[256];
        build_depths_reply(state, reply, sizeof(reply));
        send_reply(session->control_sock, reply);
    } else if (!strcmp(line, "ARMED?")) {
        pthread_mutex_lock(&state->lock);
        int armed = state->armed;
        pthread_mutex_unlock(&state->lock);
        send_reply(session->control_sock, armed ? "1\n" : "0\n");
    } else if (!strcmp(line, "*OPC?")) {
        send_reply(session->control_sock, "1\n");
    } else if (!strncmp(line, "DEPTH ", 6)) {
        uint64_t depth = parse_u64(line + 6, "DEPTH");
        if (depth < 1) {
            depth = 1;
        }
        if (depth > state->bridge->ring.size) {
            depth = state->bridge->ring.size;
        }
        pthread_mutex_lock(&state->lock);
        state->sample_depth = depth;
        pthread_mutex_unlock(&state->lock);
    } else if (!strncmp(line, "RATE ", 5)) {
        /* The bridge advertises exactly one fixed rate per launch. */
    } else if (!strcmp(line, "START") || !strcmp(line, "SINGLE") ||
               !strcmp(line, "FORCE")) {
        pthread_mutex_lock(&state->lock);
        state->armed = 1;
        pthread_mutex_unlock(&state->lock);
    } else if (!strcmp(line, "STOP")) {
        pthread_mutex_lock(&state->lock);
        state->armed = 0;
        pthread_mutex_unlock(&state->lock);
    }
}

static void *control_thread_main(void *arg)
{
    struct session_ctx *session = (struct session_ctx *)arg;
    char line[1024];

    while (!interrupted) {
        int rc = recv_line(session->control_sock, line, sizeof(line));
        if (rc <= 0) {
            break;
        }
        handle_command(session, line);
    }

    shutdown(session->data_sock, SHUT_RDWR);
    return NULL;
}

static void *data_thread_main(void *arg)
{
    struct session_ctx *session = (struct session_ctx *)arg;

    while (!interrupted) {
        uint8_t command;
        ssize_t rc = recv(session->data_sock, &command, 1, 0);
        if (rc < 0) {
            if (errno == EINTR) {
                continue;
            }
            break;
        }
        if (rc == 0) {
            break;
        }
        if (command == 'K') {
            if (send_frame(session) < 0) {
                break;
            }
        }
    }

    shutdown(session->control_sock, SHUT_RDWR);
    return NULL;
}

static int serve(int control_port, int data_port, struct server_state *state)
{
    int control_listener = create_listener(control_port);
    if (control_listener < 0) {
        return 1;
    }
    int data_listener = create_listener(data_port);
    if (data_listener < 0) {
        close(control_listener);
        return 1;
    }

    fprintf(stderr,
            "ngscopeclient connection string: frameoscope:dslabs:twinlan:localhost:%d:%d\n",
            control_port, data_port);

    while (!interrupted) {
        int control_sock = accept_client(control_listener, "control");
        if (control_sock < 0) {
            break;
        }
        int data_sock = accept_client(data_listener, "data");
        if (data_sock < 0) {
            close(control_sock);
            break;
        }

        struct session_ctx session;
        session.state = state;
        session.control_sock = control_sock;
        session.data_sock = data_sock;

        pthread_t control_thread;
        pthread_t data_thread;
        pthread_create(&control_thread, NULL, control_thread_main, &session);
        pthread_create(&data_thread, NULL, data_thread_main, &session);
        pthread_join(control_thread, NULL);
        pthread_join(data_thread, NULL);

        close(control_sock);
        close(data_sock);
        fprintf(stderr, "client disconnected\n");
    }

    close(control_listener);
    close(data_listener);
    return interrupted ? 130 : 0;
}

static void usage(const char *argv0)
{
    fprintf(stderr,
            "usage: %s [--control-port n] [--data-port n] [--ring-mib n] "
            "[--discard bytes] [--depth samples] [--transfers n] [--size bytes] "
            "[--sample-rate hz] [--synthetic] [--quiet]\n",
            argv0);
}

int main(int argc, char **argv)
{
    int control_port = DEFAULT_CONTROL_PORT;
    int data_port = DEFAULT_DATA_PORT;
    int ring_mib = DEFAULT_RING_MIB;
    int num_transfers = DEFAULT_TRANSFERS;
    int transfer_size = DEFAULT_TRANSFER_SIZE;
    int synthetic = 0;
    int verbose = 1;
    uint64_t discard = DEFAULT_DISCARD;
    uint64_t depth = DEFAULT_DEPTH;
    uint64_t sample_rate_hz = DEFAULT_SAMPLE_RATE_HZ;

    static const struct option opts[] = {
        {"control-port", required_argument, NULL, 'c'},
        {"data-port", required_argument, NULL, 'p'},
        {"ring-mib", required_argument, NULL, 'r'},
        {"discard", required_argument, NULL, 'D'},
        {"depth", required_argument, NULL, 'd'},
        {"transfers", required_argument, NULL, 'n'},
        {"size", required_argument, NULL, 's'},
        {"sample-rate", required_argument, NULL, 'R'},
        {"synthetic", no_argument, NULL, 'S'},
        {"quiet", no_argument, NULL, 'q'},
        {"help", no_argument, NULL, 'h'},
        {0, 0, 0, 0},
    };

    for (;;) {
        int c = getopt_long(argc, argv, "c:p:r:D:d:n:s:R:Sqh", opts, NULL);
        if (c == -1) {
            break;
        }
        switch (c) {
        case 'c':
            control_port = parse_int(optarg, 1, 65535, "control port");
            break;
        case 'p':
            data_port = parse_int(optarg, 1, 65535, "data port");
            break;
        case 'r':
            ring_mib = parse_int(optarg, 1, 4096, "ring MiB");
            break;
        case 'D':
            discard = parse_u64(optarg, "discard");
            break;
        case 'd':
            depth = parse_u64(optarg, "depth");
            break;
        case 'n':
            num_transfers = parse_int(optarg, 1, 128, "transfers");
            break;
        case 's':
            transfer_size = parse_int(optarg, FTDI_PACKET_SIZE, 16 << 20, "transfer size");
            transfer_size = (transfer_size / FTDI_PACKET_SIZE) * FTDI_PACKET_SIZE;
            break;
        case 'R':
            sample_rate_hz = parse_u64(optarg, "sample rate");
            if (sample_rate_hz == 0) {
                fprintf(stderr, "invalid sample rate: %s\n", optarg);
                return 2;
            }
            break;
        case 'S':
            synthetic = 1;
            break;
        case 'q':
            verbose = 0;
            break;
        case 'h':
            usage(argv[0]);
            return 0;
        default:
            usage(argv[0]);
            return 2;
        }
    }

    install_signal_handlers();

    struct bridge_ctx bridge;
    memset(&bridge, 0, sizeof(bridge));
    bridge.num_transfers = num_transfers;
    bridge.transfer_size = transfer_size;
    bridge.synthetic = synthetic;
    bridge.verbose = verbose;
    bridge.discard_remaining = discard;
    pthread_mutex_init(&bridge.ready_lock, NULL);
    pthread_cond_init(&bridge.ready_cond, NULL);

    size_t ring_size = (size_t)ring_mib * 1024u * 1024u;
    if (ring_init(&bridge.ring, ring_size) < 0) {
        perror("ring allocation");
        return 1;
    }

    if (depth > ring_size) {
        depth = ring_size;
    }

    int rc = pthread_create(&bridge.thread, NULL,
                            synthetic ? synthetic_thread_main : usb_thread_main,
                            &bridge);
    if (rc != 0) {
        fprintf(stderr, "pthread_create failed: %s\n", strerror(rc));
        ring_destroy(&bridge.ring);
        return 1;
    }

    pthread_mutex_lock(&bridge.ready_lock);
    while (!bridge.ready) {
        pthread_cond_wait(&bridge.ready_cond, &bridge.ready_lock);
    }
    int ok = bridge.ok;
    char error[256];
    snprintf(error, sizeof(error), "%s", bridge.error);
    pthread_mutex_unlock(&bridge.ready_lock);

    if (!ok) {
        fprintf(stderr, "bridge startup failed: %s\n", error);
        bridge.stopping = 1;
        interrupted = 1;
        pthread_join(bridge.thread, NULL);
        ring_destroy(&bridge.ring);
        return 1;
    }

    fprintf(stderr, "%s capture started, ring=%zu bytes, sample_rate=%" PRIu64 " Hz\n",
            synthetic ? "synthetic" : "FT232H", bridge.ring.size,
            sample_rate_hz);

    struct server_state state;
    memset(&state, 0, sizeof(state));
    state.bridge = &bridge;
    state.sample_depth = depth;
    state.sample_rate = sample_rate_hz;
    state.armed = 1;
    pthread_mutex_init(&state.lock, NULL);

    rc = serve(control_port, data_port, &state);

    bridge.stopping = 1;
    interrupted = 1;
    pthread_join(bridge.thread, NULL);
    pthread_mutex_destroy(&state.lock);
    ring_destroy(&bridge.ring);
    pthread_mutex_destroy(&bridge.ready_lock);
    pthread_cond_destroy(&bridge.ready_cond);
    return rc;
}
